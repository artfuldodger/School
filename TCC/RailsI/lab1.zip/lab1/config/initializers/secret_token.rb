# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Lab1::Application.config.secret_token = 'b36d25a76412a46b33e34f31e0d914598a1ab151e32ae03f404f305a698f02f9994104b2f6c83f39a7ea60a53fe91a46e8d077aaa0d6d0d79a1bb21af4c765b1'
