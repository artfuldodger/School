require 'test_helper'

class GreetingHelperTest < ActionView::TestCase
end
