module GreetingHelper
end
