class GreetingController < ApplicationController
  def index
  end

end
