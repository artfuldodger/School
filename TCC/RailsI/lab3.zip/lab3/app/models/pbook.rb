class Pbook < Book
  validates :weight, :presence => true
end