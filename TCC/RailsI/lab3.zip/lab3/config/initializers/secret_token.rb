# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Lab3::Application.config.secret_token = 'b579ff006424f3b32848a110d4e5722b1cbbc70128ec03ae5ea931ecde079224b75aef79b882a91657501f4df94c3bdd2a6e209300afb0cf6e7953e1541d06c6'
